import json
from pathlib import Path
import numpy as np
import torch
from asofcast.data import sha256_file
root=Path('/mnt/data/asofcast-work/source/artifacts');a=root/'candidate-suite-first';b=root/'portable-final-suite'
counts={'raw_array_pairs':0,'gaussian_array_pairs':0,'neural_tensor_pairs':0,'neural_file_pairs':0,'case_report_pairs':0}

source_changes={}

def equal(x,y):
    if isinstance(x,torch.Tensor):
        assert isinstance(y,torch.Tensor) and torch.equal(x,y);counts['neural_tensor_pairs']+=1
    elif isinstance(x,dict):
        assert x.keys()==y.keys()
        for k in x:equal(x[k],y[k])
    elif isinstance(x,(list,tuple)):
        assert len(x)==len(y)
        for u,v in zip(x,y,strict=True):equal(u,v)
    else:assert x==y

for stage in ['development','confirmation']:
    aj=json.loads((a/stage/'aggregate.json').read_text());bj=json.loads((b/stage/'aggregate.json').read_text());assert aj==bj
    for case in sorted(p for p in (a/stage).iterdir() if p.is_dir()):
        other=b/stage/case.name
        r=json.loads((case/'report.json').read_text());s=json.loads((other/'report.json').read_text())
        for key in ['protocol','dataset_metadata','runs','selection','costs','target_scale','runtime']:
            assert r[key]==s[key],(case,key)
        counts['case_report_pairs']+=1
        changed={k:{'first':r['source_files'].get(k),'portable':s['source_files'].get(k)} for k in set(r['source_files']) | set(s['source_files']) if r['source_files'].get(k)!=s['source_files'].get(k)}
        source_changes[case.name]=changed
        for sub in [Path('paired-losses.npz'),*sorted(p.relative_to(case) for p in (case/'reference-fit').glob('*.npz'))]:
            with np.load(case/sub,allow_pickle=False) as x,np.load(other/sub,allow_pickle=False) as y:
                assert x.files==y.files
                for name in x.files:
                    assert np.array_equal(x[name],y[name]),(case,sub,name)
                    counts['raw_array_pairs' if str(sub)=='paired-losses.npz' else 'gaussian_array_pairs']+=1
        for path in (a/'models'/case.name).glob('*.pt'):
            equal(torch.load(path,map_location='cpu',weights_only=True),torch.load(b/'models'/case.name/path.name,map_location='cpu',weights_only=True))
            counts['neural_file_pairs']+=1
result={'status':'exact_match','counts':counts,
        'source_changes':source_changes,'source_change_scope':'post-result no-overwrite and serialization protections; numerical model and selection unchanged','independent_retraining':True,'independent_observation_count_increased':False,
        'aggregate_sha256':{stage:[sha256_file(p/stage/'aggregate.json') for p in [a,b]] for stage in ['development','confirmation']},
        'scope':'nine freshly trained bundles, all selected forecasts/actions and raw results; same data/seeds are not extra independent samples'}
Path('/mnt/data/asofcast-work/evidence/portable-retraining-comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
