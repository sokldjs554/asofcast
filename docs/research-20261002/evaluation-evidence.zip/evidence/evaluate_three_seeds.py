import json,sys
from pathlib import Path
from scripts.evaluate_posterior_risk import evaluate,aggregate
root=Path('/mnt/data/asofcast-work/source')
p=json.loads((root/'configs/posterior_risk_development_20261002.json').read_text())
parent=root/'artifacts'/sys.argv[1]
for seed in [42,43,44]:
 evaluate(root/'artifacts/fresh-research-bundles'/f'ETTh1-{seed}',parent/f'seed{seed}',p)
aggregate([parent/f'seed{s}' for s in [42,43,44]],parent/'aggregate.json')
