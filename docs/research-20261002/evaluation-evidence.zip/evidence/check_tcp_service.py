import json,os,subprocess,sys,time,copy,hashlib
from pathlib import Path
import numpy as np
import requests
from asofcast.bundle import load_bundle

root=Path('/mnt/data/asofcast-work/source');evidence=Path('/mnt/data/asofcast-work/evidence')
b=load_bundle(root/'artifacts/ett-m1');origin=int(b.test_origins[0]);start=origin-b.config['lookback']+1
values=b.timeline.values[start:origin+1];arrivals=b.timeline.arrivals[start:origin+1]
times=b.timeline.times[start:origin+1];hidden=arrivals>times[-1]
payload={'event_times':times.tolist(),'values':values.tolist(),'arrival_times':[[None if not np.isfinite(v) else float(v) for v in row] for row in arrivals],'columns':list(b.timeline.columns),'wait_seconds':0}
changed=copy.deepcopy(payload)
for i,c in np.argwhere(hidden):
    changed['values'][int(i)][int(c)]=float(1000000+i+c)
    changed['arrival_times'][int(i)][int(c)]=float(times[-1]+1e8)
records=[]
for repeat in range(3):
    port=18840+repeat;base=f'http://127.0.0.1:{port}'
    env={**os.environ,'ASOFCAST_ARTIFACTS':str(root/'artifacts/ett-m1'),'PYTHONPATH':'src:.'}
    log=(evidence/f'tcp-server-{repeat+1}.log').open('w')
    process=subprocess.Popen([sys.executable,'-m','uvicorn','asofcast.service:default_app','--factory','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env=env,stdout=log,stderr=log)
    checks=[]
    try:
        for _ in range(120):
            if process.poll() is not None:raise RuntimeError('server exited early')
            try:
                r=requests.get(base+'/ready',timeout=1)
                if r.status_code==200:break
            except requests.RequestException:pass
            time.sleep(.1)
        else:raise RuntimeError('service readiness failed')
        ready=r.json();assert ready['checksums_verified'];checks.append('checksummed readiness')
        r=requests.get(base+'/',timeout=5);assert r.status_code==200 and '<html' in r.text.lower();checks.append('HTML over TCP')
        p=requests.post(base+'/api/predict',json=payload,timeout=5);p.raise_for_status();p=p.json()
        q=requests.post(base+'/api/predict',json=changed,timeout=5);q.raise_for_status();q=q.json()
        for key in ['prediction','baseline_prediction','action','target_time','latest_source_times','latest_observed']:
            assert p[key]==q[key],('hidden observation affected inference',key)
        assert 'target_actual' not in p and 'target_actual_retrospective' not in p
        checks.append('unreceived values and future arrival times do not affect online inference')
        assert p['target_time']==int(times[-1]+b.config['horizon']*b.timeline.grid_seconds)
        assert all(t is None or t<=times[-1] for t in p['latest_source_times']);checks.append('fixed target and causal source timestamps')
        state=requests.get(base+'/api/acquisition',params={'case_id':0,'scenario':'outage','wait_seconds':0},timeout=5).json()
        sensor=next(x['sensor'] for x in state['candidates'] if x['eligible'])
        body={'case_id':0,'scenario':'outage','wait_seconds':0,'acquired':[],'sensor':sensor}
        after=requests.post(base+'/api/acquire',json=body,timeout=5);after.raise_for_status();after=after.json()
        waited=requests.get(base+'/api/acquisition',params={'case_id':0,'scenario':'outage','wait_seconds':b.config['waits_seconds'][-1],'acquired':sensor},timeout=5);waited.raise_for_status();waited=waited.json()
        assert state['target_time']==after['target_time']==waited['target_time'];assert sensor in waited['acquired']
        assert all(not x['eligible'] for x in waited['candidates'] if x['sensor']==sensor)
        checks.append('acquisition retained across wait; target unchanged')
        body['acquired']=[sensor];assert requests.post(base+'/api/acquire',json=body,timeout=5).status_code==422
        bad=copy.deepcopy(payload);bad['extra_unrecognized']=1
        assert requests.post(base+'/api/predict',json=bad,timeout=5).status_code==422
        assert requests.get(base+'/api/replay',params={'case_id':10**9},timeout=5).status_code==404
        checks.append('duplicate acquisition and malformed/not-found requests rejected')
        stable={k:p[k] for k in ['prediction','baseline_prediction','action','target_time','latest_source_times','latest_observed']}
        digest=hashlib.sha256(json.dumps(stable,sort_keys=True).encode()).hexdigest()
        records.append({'repeat':repeat+1,'checks':checks,'stable_inference_sha256':digest,'run_id':ready['run_id']})
    finally:
        process.terminate()
        try:process.wait(timeout=10)
        except subprocess.TimeoutExpired:process.kill();process.wait()
        log.close()
assert len({r['stable_inference_sha256'] for r in records})==1
result={'status':'passed','fresh_process_repeats':3,'checks_per_repeat':len(records[0]['checks']),'records':records,'scope':'existing model-backed local HTTP service, not a public deployment or new candidate serving integration'}
(evidence/'tcp-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
