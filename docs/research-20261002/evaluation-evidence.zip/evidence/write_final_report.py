from pathlib import Path
import json, re

root=Path('/mnt/data/asofcast-work/source')
evidence=root.parent/'evidence'
aggregate=json.loads((root/'artifacts/portable-final-suite/confirmation/aggregate.json').read_text())
audit=json.loads((evidence/'independent-audit.json').read_text())
repeat=json.loads((evidence/'retraining-comparison.json').read_text())
portable=json.loads((evidence/'portable-retraining-comparison.json').read_text())
freeze=json.loads((evidence/'confirmation-freeze.json').read_text())
env=json.loads((evidence/'environment.json').read_text())
browser=json.loads((root/'artifacts/browser-real-repeat/browser-check.json').read_text())
http=json.loads((evidence/'tcp-verification.json').read_text())
assert not aggregate['general_goal_achieved'] and not aggregate['gate']['passed']
assert repeat['status']==portable['status']=='exact_match'
for i in [1,2,3]:
    text=(evidence/f'final-tests-confirmed-{i}.log').read_text()
    assert re.search(r'\b200 passed\b',text) and 'failed' not in text
assert all(r['passed'] and r['tests']==43 for r in browser['runs'])
rows=[]
for dataset in ['Taylor','MSFT']:
    for condition in ['mixed_2811','mixed_3811','outage_2811']:
        key=f'{dataset}/{condition}';cell=aggregate['cells'][key]
        simple=cell['comparisons']['validation_simple'];legacy=cell['comparisons']['legacy_joint']
        count=sum(d>0 for d in simple['seed_improvements'])
        passed=key in audit['all_gate_conditions_passing_cells']['confirmation']
        rows.append(f"| {key} | {100*legacy['relative_improvement']:+.2f}% | {100*simple['relative_improvement']:+.2f}% | [{simple['lower95']:.6f}, {simple['upper95']:.6f}] | {count}/3 | {'수치 기준 통과' if passed else '미달'} |")
table='\n'.join(rows)
report=f'''# AsOfCast 후속 연구 결과 · 2026년 10월 2일

## 최종 판정

**전체 성능 목표 미달성. 공개 모델 승격 없음.** 이번 기록은 새 연구 후보의 구현·실측 평가·반복 재학습·회귀 검증을 수행한 결과이며, AsOfCast의 일반적인 성능 우위를 달성했다는 보고서가 아니다.

새 실측 자료 2종 × 학습 시드 3개 × 도착 조건 3개, 총 18개 설정을 평가했다. 시드별 결과를 묶은 6개 자료·조건 중 사전 지정 수치 기준을 모두 충족한 조건은 **Taylor/mixed_2811 한 개**였다. 모든 조건을 통과해야 하는 전체 판정은 실패했다. 이미 노출된 ETTh1의 9개 개발 설정은 별도이며 새 독립 자료로 세지 않았다. 이전 Jena2020/GasCO의 0/6 실패를 덮어쓰지 않았고, 서로 다른 자료의 결과를 0→1 개선이라고 부르지 않았다.

## 1. 이번에 구현한 것

기존 방식은 추가 관측 전후의 실제 절대오차 차이를 회귀했다. 새 후보에서는 학습 자료로 선형 Gaussian 시계열 모형을 만들고, 현재 도착한 정보로 추정한 예측 불확실성이 센서 취득이나 대기 후 얼마나 줄어드는지 계산했다. 여러 센서가 함께 있을 때만 도움이 되는 경우를 놓치지 않도록 가능한 센서 부분집합을 비교했다. 대기는 학습 구간에서 추정한 도착 분포와 8개 고정 난수 표본으로 계산했다.

구현은 `src/asofcast/posterior_risk.py`, `src/asofcast/posterior_policy.py`에 있다. 기존 `rollout`의 고정 목표·합법 행동·비용 계산을 그대로 사용했다. 측정 시점이 기준 시점 이후인 값, 아직 도착하지 않은 값, 최종 정답은 정책 입력으로 제공하지 않았다. 취득한 기준 시점 값은 대기 뒤에도 유지했다.

처음에는 Gaussian 예측기까지 바꾸었으나, ETTh1 개발 결과에서 같은 예측기의 단순 방법보다 좋아지는 경우가 있어도 기존 강한 예측기에 못 미쳤다. 이 실패를 보존한 뒤, **기존 예측기는 유지하고 불확실성 신호만 행동 선택에 쓰는 후보**를 함께 평가하도록 새 자료 평가 전 후보군을 고정했다. 이는 원래 예측기의 정확한 확률적 사후분포가 아니라 **위험을 추정하는 대용 신호**다. Gaussian 가정 안의 계산이 맞는다는 사실과 실제 시계열에서 판단이 좋아진다는 사실은 다르다.

예측기만 변경, 정책만 변경, 둘 다 변경, 원래 방법, 강한 단순 방법 및 단순 방법 유지까지 총 9개 평가 방법을 기록했다. 단순 기준에는 이미 목표 센서가 도착했으면 불필요하게 기다리지 않는 상태 인지 방법도 추가했다. 단순 기준을 약화시켜 성공을 만들지 않았다.

## 2. 자료와 사전 고정

| 자료 | 측정값과 크기 | 역할과 해석 범위 |
|---|---|---|
| ETTh1 | 기존 변압기 시계열 | 이미 노출된 개발 자료. 이 결과로 새 자료 우위를 선언하지 않았다. |
| Taylor | 전력 수요 4,032개, 30분 간격, MW | 이번 연구에서 처음 최종 평가한 자료. 전체 12주 순서를 사용했다. |
| MSFT | 7,983개 거래 관측의 Open/High/Low/Close/Volume | 다른 분야의 새 확인 자료. 투자 성과나 체결 가격 예측의 우위를 검증한 것이 아니다. |

Taylor 원 제공자는 2000-06-05~2000-08-27의 자료로 설명한다. 번들에 원래 시계 정렬 정보가 없어 계산용 `2000-01-01` 기준점을 명시적으로 사용했다. 원래 관측 시각을 복원했다는 뜻은 아니다. MSFT의 원 날짜 1986-03-13~2017-11-10은 별도 대응표로 보존했고, 계산의 한 칸은 **거래 관측 한 개**다. 주말·휴일까지 실제 도착 지연으로 해석할 수 없다.

측정값은 실제 자료지만 **도착 기록, 센서 정보 비용과 취득 지연은 실측 운영 자료가 아니다.** 도착·비용을 시뮬레이션하고 취득 지연을 0으로 두었다. 실제 설비의 비용 절감이나 기업 운영 효과를 입증하지 않았다. 자료는 모델 점수를 보기 전에 로컬 번들의 가용성·길이·분야 차이로 골랐고 전체 기간을 사용했다. 원본 숫자 셀과 준비한 CSV의 해시를 보존했다.

동학 학습은 train에서, 위험 보정은 policy에서, 후보 선택은 validation에서 수행했다. 최종 평가 점수는 후보 선택에 쓰지 않았다. 시간순 분할 55/20/10/15%, 관측 48칸, 미래 목표 6칸, 시작점 간격 4칸을 유지했다. 자료마다 마감은 한 관측 간격이고 판단 시점은 0·절반·마감이다.

후보·조건·비용·판정 기준은 **새 자료의 첫 모델 성적을 보기 전에 로컬 커밋으로 고정**했다. 공개 원격 사전등록을 했다는 뜻은 아니다.

- 원격 원본 main: `80f2124c64e4ce7f4e4cd44d04a4570c65e3e86c`
- 복구에 사용한 원격 소스 아카이브: `5a239b2ee738062e946ae86e7a71d654179b7040`
- 아카이브 Git 트리: `47a4f2003c187b47d143e5379984eda121d7b3cd` — 145개 추적 파일의 blob 해시 일치
- 새 자료 평가 전 로컬 고정 커밋: `{freeze['code_commit']}`
- 고정 프로토콜 SHA-256: `{freeze['protocol_sha256']}`

로컬 저장소는 검증한 소스 아카이브를 가져와 초기화했으므로 로컬 커밋은 원격 저장소의 같은 해시를 뜻하지 않는다. 첫 평가 뒤에는 출력 덮어쓰기 방지, 자료 직렬화의 줄바꿈 고정, 이동 가능한 실행 명령과 패키징을 보완했다. 수치 모형·비용·선택 기준은 바꾸지 않았고, 최종 실행기로 전 과정을 다시 학습해 원시 수치가 정확히 같은지 확인했다.

## 3. 변경하지 않은 완료 기준

평가 손실은 다음과 같다.

`학습 척도로 표준화한 절대오차 + 0.03 × 총 상대 취득 비용 + 0.02 × 대기시간/마감`

각 사전 지정 자료·도착 조건에서 원래 정책과 강한 단순 기준 **각각** 대비 평균 손실 1% 이상 감소, 개선량의 paired-block 95% 구간 하한 양수, 세 학습 시드 모두 양수 개선, 각 시드의 원단위 MAE 악화 최대 1%를 요구했다. 여섯 조건 전부가 통과해야 전체 성공이다. 시드는 42/43/44, 조건은 mixed_2811/mixed_3811/outage_2811이다.

## 4. 새로운 자료의 전체 결과

개선율은 양수일 때 손실 감소다. 아래 구간은 백분율이 아니라 **강한 단순 기준 손실 − 후보 손실**의 표준화 손실 단위다. 각 개선율은 세 학습 시드의 평균 결과다.

| 자료 / 조건 | 원래 정책 대비 개선 | 강한 단순 기준 대비 개선 | 단순 기준 대비 95% 구간 | 단순 기준보다 개선된 시드 | 해당 조건 판정 |
|---|---:|---:|---|---:|---|
{table}

**Taylor/mixed_2811의 제한된 성과:** 강한 단순 기준 대비 손실이 약 5.82% 낮았으며 사전 지정 주 판정 기준은 통과했다. 그러나 보조 민감도 분석에서 블록 길이를 42개 시작점에서 6개로 바꾸면 구간이 0을 포함했다. 이 한 조건을 시간적 의존성에 관계없이 안정적인 우위가 입증된 것으로 표현하지 않는다.

**Taylor의 나머지 두 조건:** mixed_3811은 평균 개선이 1%에 못 미쳤고 주 구간도 0을 포함했다. outage_2811은 평균 개선이 약 5.60%였지만 주 구간이 0을 포함해 실패했다. 이 두 조건에서 평균이 양수라는 이유로 성공 처리하지 않았다.

**MSFT:** validation 선택이 강한 단순 방법을 그대로 유지했다. 단순 기준 대비 개선은 세 조건 모두 정확히 0이다. 원래 정책보다 비용 포함 평균 손실이 낮아져도 강한 단순 기준을 이긴 결과가 아니며, 일부 시드의 MAE 제한도 통과하지 못했다.

Taylor 최종 평가의 공유 시작점은 조건당 138개, MSFT는 287개다. 42개 시작점 블록으로 약 3.3개·6.8개 블록에 해당하므로 시계열별 불확실성 평가의 한계가 있다. 세 학습 시드의 같은 목표 시점은 독립 표본 세 개로 부풀리지 않았다. 신뢰구간은 관측된 시계열과 해당 시드에 조건부이며 다른 장소·기업 전체를 대표하지 않는다.

원시 예측, 행동열, 비용, 정답, 목표 시각, 원단위 오차, 후보 선택 이력과 모든 비교는 `artifacts/portable-final-suite/` 아래에 있다. `confirmation/aggregate.json`의 `general_goal_achieved`와 `gate.passed`는 모두 `false`다.

## 5. 실제로 수행한 검증

| 항목 | 확인 결과 | 증거 |
|---|---|---|
| 원본 기준점 | 145개 Git blob 및 ZIP/tar 무결성, 기존 테스트 165개 통과 | `evidence/source-verification.json`, `baseline-tests.log` |
| 전체 테스트 | 기존 165개와 추가 35개를 합한 200개를 최종 세 번 실행, 모두 통과 | `evidence/final-tests-confirmed-1.log`~`3.log` |
| 새 자료 평가 | 새 자료 18개 설정 및 별도 ETTh1 개발 9개 설정, 각각 9개 방법 | 세 전체 실행 폴더와 `finished.json` |
| 독립 재학습 | 첫 실행, 두 번째 전체 재학습, 이동 가능한 최종 명령의 세 번째 전체 재학습 완료 | `candidate-suite-first`, `candidate-suite-repeat`, `portable-final-suite` |
| 수치 재현 | 실행 쌍마다 원시 배열 2,268개, Gaussian/도착 모형 배열 297개, 신경망 체크포인트 54개 속 텐서 432개 정확히 일치 | `evidence/retraining-comparison.json`, `portable-retraining-comparison.json` |
| 별도 계산 감사 | 각 실행의 행동열 86,265개와 배열 2,268개, bootstrap 구간 360개를 별도 코드로 두 번 재계산 | `evidence/independent-audit.json`, `independent-audit-repeat.json` |
| 브라우저 회귀 | 원래 실측 ETTh1 모델 번들로 Chromium 화면 검사 43개 × 3회 통과 | `artifacts/browser-real-repeat/browser-check.json` |
| 실제 TCP API | 새 Uvicorn 프로세스 3개에서 readiness·HTML·인과성·취득 유지·오류 처리 등 6개 묶음 검사 통과 | `evidence/tcp-verification.json` |
| 자료 재준비 | 최종 준비 코드로 별도 경로에 재생성한 두 CSV와 원 날짜 대응표가 원본 해시와 일치 | `evidence/source-regeneration-final.json` |

별도 감사는 다른 계산 경로로 같은 원시 자료를 확인한 것이며 외부 전문가 심사나 독립 실측 표본 추가가 아니다. 브라우저는 실제 DOM과 FastAPI/PyTorch 로컬 bridge 검증이다. TCP API 검사는 별도로 실제 로컬 소켓을 사용했다. 둘 다 **기존 공개용 모델의 회귀 검사**이며 새 연구 후보의 공개 배포를 검증한 것이 아니다.

현재 검증 환경은 Python {env['python']}, NumPy {env['packages']['numpy']}, pandas {env['packages']['pandas']}, PyTorch {env['packages']['torch']}, scikit-learn {env['packages']['scikit-learn']}, pmdarima {env['packages']['pmdarima']}, Linux CPU다. 실제 환경 전체는 `evidence/environment.json`에 있다.

## 6. 실행 방법

압축을 푼 프로젝트 루트에서 실행한다. 처음 의존성을 설치할 때는 패키지 저장소 접속이 필요하다. 데이터 준비 단계는 설치된 pmdarima 번들의 원래 실측 자료를 읽으며 다운로드 실패를 가짜 자료로 대체하지 않는다.

```sh
python -m pip install '.[dev,research,browser]'
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 python -m pytest -q
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 \\
  python scripts/run_posterior_confirmation.py --out artifacts/my-confirmation-run
```

출력 경로는 새 경로여야 한다. 위 마지막 명령은 기본 번들 9개를 처음부터 학습하고, 후보 선택·평가·전체 판정까지 수행한다. 기존 연구 증거와 공개 모델을 덮어쓰지 않는다. 배포 동작은 포함하지 않는다. 원래 ETTh1 CSV는 제공한 프로젝트 묶음의 `data/raw/ETTh1.csv`를 사용한다.

기존 UI 회귀 검사는 다음과 같이 실행한다. Chromium 경로는 설치 위치에 맞추어야 한다.

```sh
python scripts/check_browser.py --browser /usr/bin/chromium \\
  --artifacts artifacts/ett-m1 --repeats 3 --out artifacts/my-browser-check
```

`evidence`의 보존 스크립트 중 일부는 당시 작업 경로를 그대로 포함한 실행 증거다. 이동 가능한 연구 실행 진입점은 `scripts/run_posterior_confirmation.py`다. 라이브러리 설치만 검증한 것과 모든 의존성을 빈 OS에 새로 설치한 검증은 다르다. Windows/macOS와 Docker 환경의 새 검증을 했다고 주장하지 않는다.

## 7. 공개 상태와 남은 경계

이번 작업에서 원격 main, 공개 예측 모델, Render 서비스는 변경하지 않았다. 새 연구 모듈을 공개 API에 연결하거나 자동 승격하지 않았다. 최신 원격 CI·공개 URL의 가동 상태를 이 로컬 결과로 대체하지 않는다. Docker 및 Ruff 실행은 이 환경에서 수행하지 않았다. 이 항목들을 통과했다고 기록하지 않는다.

남은 핵심은 단순 방법보다 비용 포함 손실을 **모든 사전 지정 독립 조건에서 안정적으로 줄이는 것**이다. 새 후보가 그 목표를 이미 달성했다고 하거나, 추가 반복만 하면 반드시 달성한다고 단정하지 않는다. 이번에 사용한 Taylor/MSFT의 최종 구간도 이제 결과가 노출되었으므로 향후 변경한 정책을 같은 구간에 다시 평가해 새로운 독립 확인이라고 부를 수 없다.

## 8. 자료·방법 출처

- Taylor 원 제공자 문서: https://pkg.robjhyndman.com/forecast/reference/taylor.html
- pmdarima Taylor 로더: https://alkaline-ml.com/pmdarima/modules/generated/pmdarima.datasets.load_taylor.html
- pmdarima MSFT 자료 설명: https://alkaline-ml.com/pmdarima/usecases/stocks.html
- MSFT 로더가 인용한 자료 제공자: https://www.kaggle.com/borismarjanovic/price-volume-data-for-all-us-stocks-etfs
- 센서 선택 연구 배경: Joshi & Boyd, *Sensor Selection via Convex Optimization* (2009), https://web.stanford.edu/~boyd/papers/sensor_selection.html . 이 구현은 전수 부분집합 비교를 사용하며 해당 논문의 최적화 알고리즘 재현을 주장하지 않는다.
- 원래 AsOfCast 코드: https://github.com/sokldjs554/asofcast/tree/80f2124c64e4ce7f4e4cd44d04a4570c65e3e86c
'''
p=root/'docs/research-20261002/RESULTS_KO.md';p.write_text(report)
(root/'docs/research-20261002/EXECUTION_PLAN.md').write_text('''# AsOfCast 사후분산 정책 후속 작업 기록

목표는 여러 독립 실측 조건에서 원래 정책과 강한 단순 기준을 모두 이기는 것이다. 비용 .03/.02, 손실 >=1% 개선, 주 block95% 구간 하한>0, 모든 시드 개선, MAE 악화<=1%, 모든 사전 지정 조건 통과를 유지했다.

- [x] 원본 소스 145개 blob 및 모델 번들 무결성 확인, 기준 테스트 165개 실행.
- [x] Gaussian 관측 필터, 도착 생존분포, 센서 부분집합 및 대기 위험 후보 구현과 인과성 검사.
- [x] ETTh1 개발 세 시드·세 도착 조건 평가; Gaussian 예측기의 약점과 실패 보존.
- [x] 기존 예측기 유지 후보 및 상태 인지 단순 기준을 추가하고 새 자료 평가 전에 로컬 고정.
- [x] Taylor/MSFT 전체 실측 자료 준비, 숫자 셀·시각 해석·해시 보존.
- [x] 새 자료 18개 설정과 개발 9개 설정, 9개 방법 평가.
- [x] 처음부터 독립 재학습 및 이동 가능한 최종 명령으로 총 세 번 전체 실행, 수치 일치 대조.
- [x] 전체 테스트 200개 세 번, 브라우저 43개 세 번, 실제 TCP 세 프로세스 검증.
- [x] 별도 계산 경로로 원시 행동·비용·정답·구간·판정 감사 두 번 실행.
- [x] 코드·패키지·결과·증거·제한사항 정리.
- [ ] 전체 성능 목표 달성: 여섯 새 조건 중 한 조건만 주 수치 기준 통과. 미달성.
- [ ] 공개 모델 승격: 미수행. 전체 기준 실패이므로 자동 배포하지 않음.

로컬 소스는 검증한 원격 아카이브에서 복구한 별도 Git 초기화다. 원격 main/공개 서비스 수정은 하지 않았다. 앞선 격리 합성 crossfit 검사는 이번 실측 증거에 포함하지 않았다. 각 실패는 원본 결과와 함께 보존한다. 최신 판정·명령·검증 범위는 RESULTS_KO.md에 있다.
''')
readme=root/'README.md';s=readme.read_text();needle='## 29초 데모로 먼저 보기'
note='''## 2026-10-02 후속 연구 · 이 로컬 검증 묶음

**전체 성능 목표는 여전히 미달성입니다.** 예측 불확실성으로 추가 관측의 가치를 추정하는 후보와 기존 예측기 유지 대조를 구현했습니다. 새 전력·거래 시계열 18개 설정을 평가했으며, 6개 자료·도착 조건 중 주 수치 기준을 모두 통과한 조건은 1개였습니다. 비용·합격 기준을 낮추지 않았고 공개 모델을 교체하지 않았습니다. 원격 README에 반영된 상태라는 뜻은 아닙니다.

[전체 결과와 실패 조건](docs/research-20261002/RESULTS_KO.md) · [고정 프로토콜](configs/posterior_candidate_confirmation_20261002.json) · [실행기](scripts/run_posterior_confirmation.py)

'''
assert needle in s and '## 2026-10-02 후속 연구' not in s
readme.write_text(s.replace(needle,note+needle,1))
status={'general_goal_achieved':False,'promotion':False,'new_dataset_settings':18,'new_dataset_cells':6,
        'numerically_passing_cells':audit['all_gate_conditions_passing_cells']['confirmation'],
        'development_settings':9,'methods_per_setting':9,'fresh_training_suite_runs':3,
        'retraining_pair_counts':repeat['counts'],'unit_tests_per_run':200,'unit_test_runs':3,
        'browser_tests_per_run':43,'browser_runs':3,'tcp_fresh_processes':3,
        'independent_audit_runs':2,'paths_per_audit':audit['action_paths_checked'],
        'arrays_per_audit':audit['arrays_checked'],'intervals_per_audit':audit['independent_intervals_checked'],
        'remote_main_modified':False,'public_model_replaced':False,'remote_preregistration':False,
        'docker_run':False,'ruff_run':False,'public_live_endpoint_rechecked':False,
        'freeze':freeze,'confirmation_results':aggregate,'limitations':['one passing primary cell is not full success',
        'Taylor passing cell does not pass the block6 sensitivity check','new measurements are real; arrivals/costs are simulated',
        'MSFT uses trading-observation ordering, not elapsed calendar-day latency','Linux CPU validation only',
        'new candidate not served by public or local production API','local reconstructed Git history, not remote pushed commits']}
(evidence/'FINAL_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
print(p)
