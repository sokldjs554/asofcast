from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/mnt/data/asofcast-work/source');work=root.parent
stage=Path('/mnt/data/AsOfCast_research_20261002');stage.mkdir(exist_ok=False)

def copy(source,dest):
    if source.is_dir():
        for p in source.rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts:
                copy(p,dest/p.relative_to(source))
        return
    assert source.suffix.lower() not in {'.ttf','.otf','.woff','.woff2'},source
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)

tracked=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
for name in filter(None,tracked):copy(root/name,stage/name)
copy(root/'artifacts/ett-m1',stage/'artifacts/ett-m1')
copy(root/'data/raw/ETTh1.csv',stage/'data/raw/ETTh1.csv')
if (root/'data/raw/ETTh1.source.json').exists():copy(root/'data/raw/ETTh1.source.json',stage/'data/raw/ETTh1.source.json')
for name in ['candidate-suite-first','candidate-suite-repeat','portable-final-suite']:
    source=root/'artifacts'/name
    for p in source.iterdir():
        if p.name=='models':continue
        copy(p,stage/'artifacts'/name/p.name)
copy(root/'artifacts/posterior-three-seeds',stage/'artifacts/posterior-three-seeds')
copy(root/'artifacts/browser-real-repeat',stage/'artifacts/browser-real-repeat')
copy(work/'evidence',stage/'evidence')
copy(work/'deliverable-metadata',stage/'provenance')
for name in ['GIT_TREE.txt','SOURCE_COMMIT.txt','SHA256SUMS.txt']:
    copy(work/'export'/name,stage/'provenance/original-export'/name)
copy(work/'wheels/asofcast-0.1.0-py3-none-any.whl',stage/'packages/asofcast-0.1.0-py3-none-any.whl')
copy(root/'docs/research-20261002/RESULTS_KO.md',stage/'RESULTS_KO.md')
copy(root/'docs/research-20261002/RESULTS_KO.md',Path('/mnt/data/AsOfCast_research_20261002_REPORT_KO.md'))
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
status=json.loads((work/'evidence/FINAL_STATUS.json').read_text())
status['delivered_local_source_commit']=commit;status['delivered_to_remote']=False
(stage/'FINAL_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
(stage/'START_HERE_KO.md').write_text('''# AsOfCast 연구 결과 묶음

**전체 성능 목표 미달성.** 새 자료 6개 조건 중 주 수치 기준을 통과한 조건은 1개이며 공개 모델을 교체하지 않았다. 먼저 `RESULTS_KO.md`를 읽는다.

## 포함 내용
소스·테스트·고정 프로토콜·새 실행기, 세 번의 전체 실험 원시 평가 배열과 선택 이력, 별도 감사·회귀 검증 로그, 원래 ETTh1 데모 번들·CSV, 검증한 wheel, 로컬 Git 이력 및 변경 patch를 포함했다. 일부 evidence 스크립트는 실제 실행 당시의 절대 경로를 그대로 보존했다.

새 Taylor/MSFT 전체 원자료와 각 전체 실행의 기본 재학습 모형 번들은 중복 배포하지 않았다. 이 자료는 pmdarima 2.1.1의 공식 번들에서 다시 준비되며 실행기가 새로운 결과 폴더에 기본 모형까지 모두 재학습한다. 예측·행동·정답·비용의 원시 평가 배열과 Gaussian 기준 모형은 포함되어 있다. `artifacts/ett-m1`의 원래 데모 번들은 바로 로드할 수 있다.

## 설치와 재현
검증 환경은 Linux CPU, Python 3.13.5다. `docs/research-20261002/VERIFIED_ENVIRONMENT.txt`에 실제 버전이 있다. 최초 의존성 설치에는 인터넷이 필요하다. 현재 컴퓨터에 이미 의존성이 설치되어 있다면 제공 wheel로 라이브러리를 설치할 수도 있다. Windows/macOS 및 Docker 검증을 했다는 뜻은 아니다.

```sh
python -m pip install '.[dev,research,browser]'
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 python -m pytest -q
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 python scripts/run_posterior_confirmation.py --out artifacts/my-new-run
```

출력 폴더는 기존에 없는 경로로 지정한다. 새 측정 자료를 합성 데이터로 대체하지 않으며 원본 해시가 다르면 중단한다. 이 명령은 자동 배포를 하지 않는다. 재실행으로 새로 생성한 모형 번들은 `artifacts/my-new-run/models`에 있으며, 그 실행을 별도 감사하려면 다음을 사용한다.

```sh
PYTHONPATH=src:. python evidence/audit_candidate_suite.py artifacts/my-new-run --out artifacts/my-new-audit.json
```

## 무결성과 소스 이력
`SHA256SUMS.txt`와 `MANIFEST.json`으로 파일을 확인할 수 있다. Linux에서는 `sha256sum -c SHA256SUMS.txt`, macOS에서는 `shasum -a 256 -c SHA256SUMS.txt`를 사용한다. 무결성 검사는 성능 목표 통과를 의미하지 않는다.

`provenance/asofcast-research-history.bundle`은 원격 소스 아카이브를 가져와 초기화한 로컬 연구 이력이다. 원격 저장소 전체 과거 이력이 아니며 원격에 push한 상태도 아니다. `provenance/research-changes.patch`는 그 가져온 소스와 최종 소스의 차이다.
''')
metadata={'source_import_commit':subprocess.check_output(['git','rev-parse','4bab339'],cwd=root,text=True).strip(),
    'final_local_commit':commit,'remote_base_main':'80f2124c64e4ce7f4e4cd44d04a4570c65e3e86c',
    'remote_source_export':'5a239b2ee738062e946ae86e7a71d654179b7040',
    'pushed':False,'full_general_goal_achieved':False,'measured_new_data_numeric_cells_passing':1,
    'not_included':['Full Taylor/MSFT prepared source series','All nine original-neural retraining bundles per suite; regenerate using portable runner'],
    'included':['Complete tracked source and local Git history','Original user-provided ETTh1 bundle and source CSV','Three suites of paired outcomes, selections and fitted Gaussian parameters','Test, browser, HTTP, audit and equality evidence']}
(stage/'provenance/DELIVERY.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
print(stage)
