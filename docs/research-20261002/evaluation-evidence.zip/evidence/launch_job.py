import argparse, subprocess, json, time, os
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
root=Path(__file__).resolve().parent
start=time.monotonic()
with (root/(a.name+'.log')).open('w') as log:
 code=subprocess.call(a.command,stdout=log,stderr=subprocess.STDOUT)
(root/(a.name+'-exit.json')).write_text(json.dumps({'returncode':code,'elapsed_seconds':time.monotonic()-start,'command':a.command}))
