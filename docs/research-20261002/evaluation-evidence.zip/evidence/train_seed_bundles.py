import json,time,sys
from pathlib import Path
from asofcast.experiment import run_experiment
from asofcast.data import sha256_file
root=Path('/mnt/data/asofcast-work/source')
cfg=json.loads((root/'configs/ett_m1.json').read_text())
start=time.monotonic(); manifest={}
for seed in [42,43,44]:
    out=root/'artifacts'/sys.argv[1]/f'ETTh1-{seed}'
    if out.exists():raise FileExistsError(out)
    print(json.dumps({'training':seed,'out':str(out),'elapsed':time.monotonic()-start}),flush=True)
    run_experiment(root/'data/raw/ETTh1.csv',out,{**cfg,'seed':seed},source_kind='ett')
    manifest[str(seed)]={'manifest_sha256':sha256_file(out/'manifest.json'),'directory':str(out)}
    print(json.dumps({'trained':seed,'elapsed':time.monotonic()-start}),flush=True)
Path('/mnt/data/asofcast-work/evidence/'+sys.argv[1]+'-bundles.json').write_text(json.dumps(manifest,indent=2))
