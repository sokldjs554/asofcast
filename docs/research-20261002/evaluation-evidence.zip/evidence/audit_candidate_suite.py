"""Separate audit of raw action paths, fees, targets, losses and bootstrap intervals."""
import argparse, json, math
from pathlib import Path
import numpy as np
from asofcast.bundle import load_bundle
from asofcast.data import sha256_file
from asofcast.preprocessing import simulate_arrivals


def interval_shadow(delta,block,repeats,seed):
    series=np.asarray(delta,dtype=float).sum(0)/len(delta)
    n=len(series);gen=np.random.default_rng(seed);means=[]
    for _ in range(repeats):
        starts=gen.integers(0,n,size=math.ceil(n/block))
        sampled=[]
        for start in starts:sampled.extend(series[(int(start)+np.arange(block))%n])
        means.append(sum(sampled[:n])/n)
    ordered=np.sort(means)
    def percentile(p):
        k=p*(repeats-1);i=int(k)
        return float(ordered[i]+(k-i)*(ordered[min(i+1,repeats-1)]-ordered[i]))
    return dict(mean=float(series.mean()),lower95=percentile(.025),upper95=percentile(.975),
                seed_improvements=np.asarray(delta).mean(1).tolist())


def audit(root):
    root=Path(root);total_paths=0;array_count=0;intervals=0;cells_passed={};sources={}
    for stage in ['development','confirmation']:
        summary=json.loads((root/stage/'aggregate.json').read_text())
        case_dirs=sorted(p for p in (root/stage).iterdir() if p.is_dir());loaded={};reports={}
        for case in case_dirs:
            report=json.loads((case/'report.json').read_text());ds,seed=report['dataset'],report['seed']
            assert sha256_file(case/'paired-losses.npz')==report['raw_sha256']
            bundle=load_bundle(root/'models'/case.name);raw=bundle.timeline
            assert sha256_file(root/'models'/case.name/'manifest.json')==report['bundle_manifest_sha256']
            assert bundle.report['source']['sha256']==report['dataset_metadata']['prepared_sha256']
            data=np.load(case/'paired-losses.npz',allow_pickle=False);array_count+=len(data.files)
            loaded[ds,seed]={k:data[k] for k in data.files};data.close();a=loaded[ds,seed];reports[ds,seed]=report
            costs=np.asarray(report['costs'],float);scale=float(report['target_scale']);grid=raw.grid_seconds
            n=len(raw.times);expected_origins=np.arange(int(.85*n)+47,n-6,4)
            for condition in report['protocol']['conditions']:
                name=condition['name'];origin=a[name+'__origins'];np.testing.assert_array_equal(origin,expected_origins)
                arrival=simulate_arrivals(raw.times,len(raw.columns),condition['arrival_seed'],profile=condition['profile'])
                truth=bundle.scaler.transform(raw.values)[origin+6,bundle.manifest['target_channel']]
                np.testing.assert_array_equal(truth,a[name+'__truth'])
                for method,averages in report['runs'][name].items():
                    pre=name+'__'+method+'__';actions=a[pre+'actions'];paid=[];waited=[];counts=[]
                    for o,path in zip(origin,actions,strict=True):
                        step=0;used=set();fee=0.;stopped=False
                        for action in path:
                            if stopped:
                                assert action==-9,'non-padding after commit';continue
                            assert action!=-9,'padding before commit'
                            if action==-1:stopped=True
                            elif action==-2:
                                assert step<2,'late WAIT';step+=1
                            else:
                                c=int(action);assert 0<=c<len(costs) and c not in used,'invalid/repeated pull'
                                assert arrival[o,c]>raw.times[o]+step*grid/2,'pull of received origin slot'
                                used.add(c);fee+=float(costs[c])
                        assert stopped,'no COMMIT';paid.append(fee);waited.append(step*grid/2);counts.append(len(used))
                    paid=np.asarray(paid);waited=np.asarray(waited)
                    err=np.abs(a[pre+'prediction']-truth)
                    objective=err+.03*paid+.02*waited/grid
                    expected={'cost':paid,'wait_seconds':waited,'acquired_count':np.asarray(counts),
                        'objective':objective,'native_error':err*scale,'deadline_violation':np.zeros(len(origin)),
                        'target_times':raw.times[origin]+6*grid}
                    for field,values in expected.items():np.testing.assert_allclose(values,a[pre+field],rtol=0,atol=1e-12)
                    for field,avg in averages.items():
                        np.testing.assert_allclose(np.mean(a[pre+field]),avg,rtol=0,atol=1e-12)
                    total_paths+=len(origin)
            sources[str(case.relative_to(root))]=report['raw_sha256']
        passed=[]
        for cell,record in summary['cells'].items():
            ds,condition=cell.split('/');baseorig=loaded[ds,42][condition+'__origins']
            for s in [43,44]:np.testing.assert_array_equal(baseorig,loaded[ds,s][condition+'__origins'])
            for comparison,stored in summary['diagnostics'][cell].items():
                candidate,comparator=comparison.split('/')
                delta=np.stack([loaded[ds,s][condition+'__'+comparator+'__objective']-
                    loaded[ds,s][condition+'__'+candidate+'__objective'] for s in [42,43,44]])
                for block,entry in [(42,stored),(6,stored['sensitivity_block6'])]:
                    independent=interval_shadow(delta,block,2000,20260929)
                    for k in ['mean','lower95','upper95','seed_improvements']:
                        np.testing.assert_allclose(independent[k],entry[k],rtol=0,atol=1e-12)
                    intervals+=1
            ok=True
            for c in ['legacy_joint','validation_simple']:
                x=record['comparisons'][c]
                ok &= x['relative_improvement']>=.01 and x['lower95']>0 and all(v>0 for v in x['seed_improvements'])
            ok &= all(r<=.01 for r in record['mae_regressions'])
            if ok:passed.append(cell)
        assert summary['gate']['passed']==(len(passed)==len(summary['cells']))
        cells_passed[stage]=passed
    result={'status':'passed','suite':str(root),'action_paths_checked':total_paths,'arrays_checked':array_count,
        'independent_intervals_checked':intervals,'all_gate_conditions_passing_cells':cells_passed,
        'source_arrays_sha256':sources,'scope':'separate raw arithmetic/path/bootstrap implementation; same documented arrival generator; not external peer review'}
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('suite');p.add_argument('--out',required=True);a=p.parse_args()
    out=Path(a.out)
    if out.exists():raise FileExistsError(out)
    result=audit(a.suite);out.write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='source_arrays_sha256'}))
