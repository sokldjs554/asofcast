import argparse,json,time,subprocess
from pathlib import Path
from asofcast.experiment import run_experiment
from asofcast.data import sha256_file,write_json
from scripts.posterior_candidate_suite import evaluate_case,aggregate_suite,source_hashes
p=argparse.ArgumentParser();p.add_argument('--name',required=True);a=p.parse_args()
root=Path('/mnt/data/asofcast-work/source');out=root/'artifacts'/a.name
if out.exists():raise FileExistsError(out)
out.mkdir(parents=True)
protocol_path=root/'configs/posterior_candidate_confirmation_20261002.json'
protocol=json.loads(protocol_path.read_text());cfg=json.loads((root/'configs/ett_m1.json').read_text())
lock={**source_hashes(),**{str(p.relative_to(root)):sha256_file(p) for p in root.glob('configs/*.json')}}
write_json(out/'execution-lock.json',{'source_files':lock,'launcher_sha256':sha256_file(Path(__file__)),'code_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'protocol_sha256':sha256_file(protocol_path)})
started=time.monotonic()
for development,metas in [(True,protocol['development_datasets']),(False,protocol['confirmatory_datasets'])]:
 for dataset,meta in metas.items():
  source=root/('data/raw/ETTh1.csv' if development else f'data/posterior-confirmation/{dataset}.csv')
  for seed in [42,43,44]:
   if lock!={**source_hashes(),**{str(p.relative_to(root)):sha256_file(p) for p in root.glob('configs/*.json')}}:raise RuntimeError('execution lock changed')
   bundle=out/'models'/f'{dataset}-{seed}'
   runconfig={**cfg,'target':meta['target'],'seed':seed,'waits_seconds':[0,meta['grid_seconds']/2,meta['grid_seconds']]}
   print(json.dumps({'training':dataset,'seed':seed,'elapsed':time.monotonic()-started}),flush=True)
   run_experiment(source,bundle,runconfig,source_kind='ett' if development else 'user-provided-csv')
   print(json.dumps({'evaluating':dataset,'seed':seed,'elapsed':time.monotonic()-started}),flush=True)
   evaluate_case(bundle,out/('development' if development else 'confirmation')/f'{dataset}-{seed}',protocol,dataset,development=development)
 summary=aggregate_suite(out/('development' if development else 'confirmation'),protocol,development=development)
 print(json.dumps({'stage_complete':'development' if development else 'confirmation','goal':summary['general_goal_achieved'],'gate':summary['gate']}),flush=True)
if lock!={**source_hashes(),**{str(p.relative_to(root)):sha256_file(p) for p in root.glob('configs/*.json')}}:raise RuntimeError('execution lock changed')
write_json(out/'finished.json',{'elapsed_seconds':time.monotonic()-started,'all_cases_executed':9,'new_dataset_settings':18,'development_settings':9,'deployment_changed':False})
